module project_Phase_3 {
    requires java.desktop;
    requires java.logging;
}